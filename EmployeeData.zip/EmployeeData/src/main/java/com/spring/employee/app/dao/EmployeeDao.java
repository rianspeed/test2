package com.spring.employee.app.dao;

public class EmployeeDao {

}
